M03 version 1.1 beta
intended only for testing enwik9 with full blocksize
Not intended for real world usage.

usage:

M03.exe e 1000000000 enwik9 enwik9.m03

M03.exe d enwik9.m03

